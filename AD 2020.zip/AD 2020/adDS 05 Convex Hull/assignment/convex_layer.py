import random
import numpy as np
import matplotlib.pyplot as plt

np.random.seed(4567)

from scipy.spatial import ConvexHull
#points = np.random.rand(30, 2)   # 30 random points in 2-D
#points = np.random.randint(100, size=(50,   2))
#                        값범위      갯수, 차원
#points

def collinear(x1, y1, x2, y2, x3, y3): 
      
    """ Calculation the area of   
        triangle. We have skipped  
        multiplication with 0.5 to 
        avoid floating point computations """
    a = x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2) 
    return a == 0

for ind in range(1,5):
	filepath = 'layer'+str(ind)+'.txt'

	with open(filepath) as f:
	    lines = f.read().splitlines()
	count = lines[0]
	lines = lines[1:]
	points = []
	for i in lines:
	    temp = i.split(" ")
	    points.append([temp[0],temp[1]])
	points = np.asarray(points).astype(int)

	with open("layer_out"+str(ind)+".txt", "a") as myfile:
	    while len(points)>2:
	        hull = ConvexHull(points, qhull_options='QJ')
	        plt.plot(points[:,0], points[:,1], 'o')

	        layers = []
	        for simplex in hull.simplices:  #convex hull edge의 List
	            plt.plot(points[simplex, 0], points[simplex, 1], 'r--', alpha=0.8)
	            layers = np.append(layers, simplex)
	        layers = np.unique(layers.astype(int))
	        points = np.delete(points, layers[1:], axis=0)
            
	        myfile.write(' '.join(layers.astype(str)))
	        myfile.write('\r\n')
	myfile.close()
	plt.show()